package com.example.Banking.Online.System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingOnlineSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
