package com.example.banking.online.system.services;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.banking.online.system.model.ThirdBalance;
import com.example.banking.online.system.repository.ThirdBalanceRepo;


@Service
public class ThirdBalanceServices{
    @Autowired
    ThirdBalanceRepo repo;
    public List<ThirdBalance>getAllBalances(){
        return repo.findAll();
    }
    public void  saveBalance(ThirdBalance balance){
        System.out.println("Inside Service Name:"+balance.getName());
        System.out.println("Inside Service Balance:"+balance.getFinalBalance());
        repo.save(balance);
    }
}