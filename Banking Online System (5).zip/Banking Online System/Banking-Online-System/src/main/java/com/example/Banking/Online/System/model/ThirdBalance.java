package com.example.banking.online.system.model;







import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class ThirdBalance{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int id;

    private String name;
    @Column(name="final_balance")
    private double finalBalance;
   

    public int getId(){
        return id;
    }
    public void setId(int id){
        this.id=id;
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name=name;
    }
    public double getFinalBalance(){
        return finalBalance;
    }
    public void setFinalBalance(double finalBalance){
        
        this.finalBalance=finalBalance;
    }

}