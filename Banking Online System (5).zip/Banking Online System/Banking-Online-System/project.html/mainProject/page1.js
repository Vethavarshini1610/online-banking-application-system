function submit() {
    var name = document.getElementById("name").value;
    var userId = document.getElementById("number").value;
    var accountnumber = document.getElementById("accountnumber").value;
    var initialamount = Number(document.getElementById("initialamount").value);
    var status = document.getElementById("status").value;
   

    if (!name || !accountnumber || !userId || !status || isNaN(initialamount)) {
        alert("Fill all Fields");
        return;
    }

    var user = {
        name: name,
        balance: initialamount,
        accountnumber: accountnumber,
        status: status
    };
    let users = JSON.parse(localStorage.getItem("users")) || [];
    if(!Array.isArray(users)){
        users=[];
    }
    users.push(user);
    localStorage.setItem("users", JSON.stringify(users));

    localStorage.setItem("currentUser", JSON.stringify(user));


   


    fetch('http://localhost:8080/api/login', {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            name:name,
            accountnumber:accountnumber,
            initialamount:initialamount,
            userID:userId,
            type:status
        })
    })
        .then(res => res.text())
        .then(data => {
            if (data === "success") {
                alert("Successfully Upload");
            } else {
                alert("Its Error ");
            }
        });



}